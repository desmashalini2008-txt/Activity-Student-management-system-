# Project Report: Student Management System
_(Fill in the bracketed placeholders with your own details, screenshots, and reflections.)_

## 1. Title and Project Overview
**Title:** Student Management System — A CRUD-Based Web Application
**Overview:** A full-stack web application that allows an administrator to
Create, Read, Update, and Delete student records through a browser-based
interface backed by a REST API and a relational database.

## 2. Problem Statement
Educational institutions need a reliable way to maintain student records
(personal details, enrolled course, enrollment date) without relying on
spreadsheets or paper records, which are error-prone and hard to search or
update. This project solves that by providing a simple web application with
validated data entry, search/filter, and persistent storage.

## 3. Objectives
- Implement all four CRUD operations end to end.
- Build a REST API following standard HTTP method conventions.
- Enforce both client-side and server-side validation.
- Provide a responsive, usable interface.
- Demonstrate reliable frontend–backend–database communication.
- Include automated and manual (Postman) test coverage.

## 4. Technology Stack
| Layer | Technology |
|---|---|
| Frontend | HTML5, CSS3, JavaScript (Fetch API) |
| Backend | Django 6 + Django REST Framework |
| Database | SQLite |
| API Testing | Postman |
| Version Control | Git / GitHub |

## 5. System Architecture
```
Browser (HTML/CSS/JS)
      │  fetch() — JSON over HTTP
      ▼
Django REST Framework API  (/api/students/)
      │  Django ORM
      ▼
SQLite Database (db.sqlite3)
```
The frontend is a static site that calls the backend's REST endpoints. The
backend exposes a `StudentViewSet` (DRF `ModelViewSet`) that maps HTTP verbs
to CRUD operations on the `Student` model, which Django's ORM persists to
SQLite. CORS is enabled so the two can be served from different origins/ports.

## 6. Database / ER Design
**Entity: Student**

| Field | Type | Constraints |
|---|---|---|
| id | AutoField (PK) | Primary key, auto-increment |
| name | CharField(100) | Required |
| email | EmailField | Required, unique |
| age | PositiveIntegerField | Required, 15–100 |
| course | CharField(10, choices) | Required, one of CSE/ECE/MECH/CIVIL/IT/OTHER |
| enrollment_date | DateField | Required, cannot be in the future |
| created_at | DateTimeField | Auto-set on creation |
| updated_at | DateTimeField | Auto-updated on save |

Single-entity design (no foreign keys needed for this scope). [Attach an
ER diagram image here if your submission requires one — e.g. exported from
dbdiagram.io or drawn by hand.]

## 7. UI Screenshots
[Insert screenshots here:]
- Add Student form (empty state)
- Add Student form (validation errors shown)
- Student list/table (populated)
- Edit Student form (pre-filled)
- Search/filter in action
- Delete confirmation

## 8. API Endpoint Documentation
| Operation | Method | Endpoint | Request Body | Success Response |
|---|---|---|---|---|
| Create | POST | `/api/students/` | Student JSON | 201 + created record |
| Read all | GET | `/api/students/?search=&course=` | — | 200 + paginated list |
| Read one | GET | `/api/students/{id}/` | — | 200 + record |
| Update | PUT | `/api/students/{id}/` | Full student JSON | 200 + updated record |
| Update | PATCH | `/api/students/{id}/` | Partial JSON | 200 + updated record |
| Delete | DELETE | `/api/students/{id}/` | — | 200 + confirmation message |

Error responses use HTTP 400 (validation errors, field-by-field) and HTTP
404 (record not found). See `postman_collection.json` for example requests.

## 9. CRUD Implementation Details
- **Create:** `StudentSerializer` validates all fields (required-ness, age
  range, email format and uniqueness, no future enrollment dates) before
  `StudentViewSet.create()` saves the record.
- **Read:** `StudentViewSet` (via DRF `ModelViewSet` + `DjangoFilterBackend`
  and `SearchFilter`) supports listing, retrieving by ID, searching by name
  or email, and filtering by course.
- **Update:** PUT/PATCH re-validate through the same serializer, excluding
  the current record from the uniqueness check on email.
- **Delete:** Removes the record and returns a confirmation message; a
  missing ID returns 404 rather than a silent no-op.

## 10. Validation Summary
| Field | Client-side | Server-side |
|---|---|---|
| name | required | required, non-blank |
| email | required, format check | required, valid format, unique |
| age | required, 15–100 | required, 15–100 |
| enrollment_date | required, not in the future | required, not in the future |

## 11. Testing Results
**Automated tests:** `backend/students/tests.py` — 13/13 passing
(`python manage.py test students -v 2`). Covers create (valid, missing
fields, duplicate email, invalid age, future date), read (empty DB,
populated DB, retrieve by ID, search), update (valid ID, invalid ID →
404), delete (valid ID, invalid ID → 404).

**Manual API tests:** Performed with the included Postman collection.
[Insert Postman screenshots / a results table here.]

**Frontend testing:** [Note what you tested manually — responsiveness on
desktop vs. mobile widths, behavior when the backend is stopped, etc.]

## 12. Installation and Execution Steps
See `README.md` in the project root for full setup instructions
(backend virtual environment, `pip install -r requirements.txt`,
`python manage.py migrate`, `runserver`; frontend served via
`python -m http.server`).

## 13. Challenges and Solutions
[Example entries — replace with your own:]
- *Challenge:* Frontend and backend run on different ports, causing CORS
  errors. *Solution:* Added `django-cors-headers` and enabled
  `CORS_ALLOW_ALL_ORIGINS` for local development.
- *Challenge:* Preventing duplicate student records. *Solution:* Added a
  unique constraint on `email` plus a serializer-level check that excludes
  the current record during updates.

## 14. Future Enhancements
- Add authentication/authorization (login-protected admin actions).
- Add pagination controls and sorting in the UI (API already supports both).
- Add bulk import/export (CSV).
- Add role-based access (admin vs. read-only staff).
- Migrate the database to PostgreSQL/MySQL for production use.

## 15. Git Repository / Reference Details
Repository: `[insert your GitHub URL after pushing]`
Commit history: `[git log --oneline summary, or link]`
