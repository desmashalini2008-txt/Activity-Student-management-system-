// ------------------------------------------------------------------
// Student Management System — frontend logic
// Talks to the Django REST API defined in API_BASE_URL (config.js)
// ------------------------------------------------------------------

const form = document.getElementById("student-form");
const idField = document.getElementById("student-id");
const nameField = document.getElementById("name");
const emailField = document.getElementById("email");
const ageField = document.getElementById("age");
const courseField = document.getElementById("course");
const enrollmentField = document.getElementById("enrollment_date");

const formTitle = document.getElementById("form-title");
const submitBtn = document.getElementById("submit-btn");
const cancelBtn = document.getElementById("cancel-edit");
const formMessage = document.getElementById("form-message");

const searchInput = document.getElementById("search-input");
const courseFilter = document.getElementById("course-filter");
const refreshBtn = document.getElementById("refresh-btn");
const statusMessage = document.getElementById("status-message");
const tbody = document.getElementById("students-tbody");

let searchDebounce = null;

// ---------- Helpers ----------

function clearFieldErrors() {
  document.querySelectorAll(".error").forEach((el) => (el.textContent = ""));
}

function showFieldErrors(errors) {
  clearFieldErrors();
  Object.entries(errors).forEach(([field, messages]) => {
    const el = document.getElementById(`err-${field}`);
    if (el) el.textContent = Array.isArray(messages) ? messages[0] : String(messages);
  });
}

function setFormMessage(text, type) {
  formMessage.textContent = text || "";
  formMessage.className = "form-message" + (type ? " " + type : "");
}

function resetForm() {
  form.reset();
  idField.value = "";
  formTitle.textContent = "Add Student";
  submitBtn.textContent = "Add Student";
  cancelBtn.classList.add("hidden");
  clearFieldErrors();
  setFormMessage("", "");
}

function clientSideValidate() {
  const errors = {};
  if (!nameField.value.trim()) errors.name = ["Name is required."];
  if (!emailField.value.trim()) {
    errors.email = ["Email is required."];
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailField.value.trim())) {
    errors.email = ["Enter a valid email address."];
  }
  const age = Number(ageField.value);
  if (!ageField.value || age < 15 || age > 100) {
    errors.age = ["Age must be between 15 and 100."];
  }
  if (!enrollmentField.value) {
    errors.enrollment_date = ["Enrollment date is required."];
  } else if (new Date(enrollmentField.value) > new Date()) {
    errors.enrollment_date = ["Enrollment date cannot be in the future."];
  }
  return errors;
}

// ---------- API calls ----------

async function apiRequest(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  let data = null;
  try {
    data = await response.json();
  } catch (_) {
    data = null;
  }
  if (!response.ok) {
    const error = new Error("Request failed");
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}

async function fetchStudents() {
  statusMessage.textContent = "Loading students...";
  const params = new URLSearchParams();
  if (searchInput.value.trim()) params.set("search", searchInput.value.trim());
  if (courseFilter.value) params.set("course", courseFilter.value);

  try {
    const data = await apiRequest(`/students/?${params.toString()}`);
    renderStudents(data.results ?? data);
    statusMessage.textContent = "";
  } catch (err) {
    statusMessage.textContent =
      "Could not reach the server. Is the Django backend running at " + API_BASE_URL + "?";
    renderStudents([]);
  }
}

async function createStudent(payload) {
  return apiRequest("/students/", { method: "POST", body: JSON.stringify(payload) });
}

async function updateStudent(id, payload) {
  return apiRequest(`/students/${id}/`, { method: "PUT", body: JSON.stringify(payload) });
}

async function deleteStudent(id) {
  return apiRequest(`/students/${id}/`, { method: "DELETE" });
}

// ---------- Rendering ----------

function renderStudents(students) {
  tbody.innerHTML = "";

  if (!students || students.length === 0) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="6">No students found.</td></tr>`;
    return;
  }

  for (const student of students) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(student.name)}</td>
      <td>${escapeHtml(student.email)}</td>
      <td>${student.age}</td>
      <td>${escapeHtml(student.course)}</td>
      <td>${escapeHtml(student.enrollment_date)}</td>
      <td class="actions-cell">
        <button class="btn btn-secondary btn-small" data-action="edit" data-id="${student.id}">Edit</button>
        <button class="btn btn-danger btn-small" data-action="delete" data-id="${student.id}">Delete</button>
      </td>
    `;
    tbody.appendChild(tr);
  }
}

function escapeHtml(value) {
  const div = document.createElement("div");
  div.textContent = value ?? "";
  return div.innerHTML;
}

// ---------- Event handlers ----------

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  clearFieldErrors();

  const clientErrors = clientSideValidate();
  if (Object.keys(clientErrors).length > 0) {
    showFieldErrors(clientErrors);
    setFormMessage("Please fix the highlighted fields.", "error");
    return;
  }

  const payload = {
    name: nameField.value.trim(),
    email: emailField.value.trim(),
    age: Number(ageField.value),
    course: courseField.value,
    enrollment_date: enrollmentField.value,
  };

  const editingId = idField.value;

  try {
    if (editingId) {
      await updateStudent(editingId, payload);
      setFormMessage("Student updated successfully.", "success");
    } else {
      await createStudent(payload);
      setFormMessage("Student added successfully.", "success");
    }
    resetForm();
    fetchStudents();
  } catch (err) {
    if (err.status === 400 && err.data) {
      showFieldErrors(err.data);
      setFormMessage("Please fix the highlighted fields.", "error");
    } else {
      setFormMessage("Something went wrong. Is the backend server running?", "error");
    }
  }
});

cancelBtn.addEventListener("click", resetForm);

tbody.addEventListener("click", async (e) => {
  const btn = e.target.closest("button[data-action]");
  if (!btn) return;
  const id = btn.dataset.id;

  if (btn.dataset.action === "edit") {
    try {
      const student = await apiRequest(`/students/${id}/`);
      idField.value = student.id;
      nameField.value = student.name;
      emailField.value = student.email;
      ageField.value = student.age;
      courseField.value = student.course;
      enrollmentField.value = student.enrollment_date;
      formTitle.textContent = "Edit Student";
      submitBtn.textContent = "Save Changes";
      cancelBtn.classList.remove("hidden");
      clearFieldErrors();
      setFormMessage("", "");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      statusMessage.textContent = "Could not load that student's details.";
    }
  }

  if (btn.dataset.action === "delete") {
    const confirmed = confirm("Delete this student record? This cannot be undone.");
    if (!confirmed) return;
    try {
      await deleteStudent(id);
      fetchStudents();
    } catch (err) {
      statusMessage.textContent = "Could not delete that student. Please try again.";
    }
  }
});

refreshBtn.addEventListener("click", fetchStudents);
courseFilter.addEventListener("change", fetchStudents);
searchInput.addEventListener("input", () => {
  clearTimeout(searchDebounce);
  searchDebounce = setTimeout(fetchStudents, 350);
});

// ---------- Init ----------
fetchStudents();
