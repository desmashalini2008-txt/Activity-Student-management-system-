// Central place to point the frontend at the backend API.
// Change this if the Django server runs on a different host/port.
const API_BASE_URL = "http://127.0.0.1:8000/api";
