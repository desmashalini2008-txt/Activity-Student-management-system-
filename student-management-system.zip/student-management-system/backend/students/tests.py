from datetime import date, timedelta

from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from .models import Student


class StudentCRUDTests(APITestCase):
    """
    Covers the SOP testing procedure (Section 10):
    Create (valid/missing/duplicate/invalid), Read (empty/populated),
    Update (valid/invalid id), Delete (valid/invalid id).
    """

    def setUp(self):
        self.list_url = "/api/students/"
        self.valid_payload = {
            "name": "Asha Rao",
            "email": "asha@example.com",
            "age": 20,
            "course": "CSE",
            "enrollment_date": "2024-06-01",
        }

    # ---- Create ----

    def test_create_valid_student(self):
        response = self.client.post(self.list_url, self.valid_payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Student.objects.count(), 1)

    def test_create_missing_required_fields(self):
        response = self.client.post(self.list_url, {"name": "No Email"}, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("email", response.data)

    def test_create_duplicate_email_rejected(self):
        self.client.post(self.list_url, self.valid_payload, format="json")
        response = self.client.post(self.list_url, self.valid_payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("email", response.data)

    def test_create_invalid_age_rejected(self):
        payload = {**self.valid_payload, "email": "x@example.com", "age": 200}
        response = self.client.post(self.list_url, payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("age", response.data)

    def test_create_future_enrollment_date_rejected(self):
        future_date = (date.today() + timedelta(days=30)).isoformat()
        payload = {**self.valid_payload, "email": "y@example.com", "enrollment_date": future_date}
        response = self.client.post(self.list_url, payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("enrollment_date", response.data)

    # ---- Read ----

    def test_list_empty_database(self):
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 0)

    def test_list_populated_database(self):
        self.client.post(self.list_url, self.valid_payload, format="json")
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)

    def test_retrieve_single_student(self):
        create_resp = self.client.post(self.list_url, self.valid_payload, format="json")
        student_id = create_resp.data["id"]
        response = self.client.get(f"{self.list_url}{student_id}/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["email"], self.valid_payload["email"])

    def test_search_by_name(self):
        self.client.post(self.list_url, self.valid_payload, format="json")
        response = self.client.get(f"{self.list_url}?search=Asha")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)

    # ---- Update ----

    def test_update_valid_id(self):
        create_resp = self.client.post(self.list_url, self.valid_payload, format="json")
        student_id = create_resp.data["id"]
        updated = {**self.valid_payload, "age": 22}
        response = self.client.put(f"{self.list_url}{student_id}/", updated, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["age"], 22)

    def test_update_invalid_id_returns_404(self):
        response = self.client.put(f"{self.list_url}9999/", self.valid_payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    # ---- Delete ----

    def test_delete_valid_id(self):
        create_resp = self.client.post(self.list_url, self.valid_payload, format="json")
        student_id = create_resp.data["id"]
        response = self.client.delete(f"{self.list_url}{student_id}/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(Student.objects.count(), 0)

    def test_delete_invalid_id_returns_404(self):
        response = self.client.delete(f"{self.list_url}9999/")
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
