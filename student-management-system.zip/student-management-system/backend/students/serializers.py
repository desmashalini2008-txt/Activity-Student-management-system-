from datetime import date

from rest_framework import serializers

from .models import Student


class StudentSerializer(serializers.ModelSerializer):
    """
    Handles validation and (de)serialization of Student records.
    Server-side validation is enforced here even though the frontend
    also validates input on the client side.
    """

    class Meta:
        model = Student
        fields = [
            'id', 'name', 'email', 'age', 'course',
            'enrollment_date', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate_name(self, value):
        if not value.strip():
            raise serializers.ValidationError("Name cannot be empty.")
        return value.strip()

    def validate_age(self, value):
        if value < 15 or value > 100:
            raise serializers.ValidationError("Age must be between 15 and 100.")
        return value

    def validate_enrollment_date(self, value):
        if value > date.today():
            raise serializers.ValidationError("Enrollment date cannot be in the future.")
        return value

    def validate_email(self, value):
        value = value.strip().lower()
        qs = Student.objects.filter(email__iexact=value)
        if self.instance:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise serializers.ValidationError("A student with this email already exists.")
        return value
