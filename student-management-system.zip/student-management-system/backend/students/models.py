from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models


class Student(models.Model):
    """
    Core entity for the Student Management System.
    Represents one student record managed through CRUD operations.
    """

    COURSE_CHOICES = [
        ('CSE', 'Computer Science & Engineering'),
        ('ECE', 'Electronics & Communication Engineering'),
        ('MECH', 'Mechanical Engineering'),
        ('CIVIL', 'Civil Engineering'),
        ('IT', 'Information Technology'),
        ('OTHER', 'Other'),
    ]

    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    age = models.PositiveIntegerField(
        validators=[MinValueValidator(15), MaxValueValidator(100)]
    )
    course = models.CharField(max_length=10, choices=COURSE_CHOICES, default='OTHER')
    enrollment_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.name} ({self.email})"
