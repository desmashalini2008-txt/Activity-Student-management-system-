# Student Management System — CRUD Web Application

A full-stack CRUD application built to the attached SOP (Standard Operating
Procedure for Complete CRUD-Based Web Application Development).

- **Frontend:** HTML, CSS, vanilla JavaScript (fetch API)
- **Backend:** Django + Django REST Framework
- **Database:** SQLite
- **API testing:** Postman collection included
- **Automated tests:** Django `APITestCase` suite (13 tests)

## Project Structure

```
student-management-system/
├── backend/
│   ├── manage.py
│   ├── requirements.txt
│   ├── .env.example
│   ├── config/            # Django project settings & URLs
│   └── students/           # App: models, serializers, views, tests
│       ├── models.py       # Student entity
│       ├── serializers.py  # Server-side validation
│       ├── views.py        # ModelViewSet: full CRUD
│       ├── urls.py         # /api/students/ router
│       ├── admin.py
│       └── tests.py        # Automated API tests
├── frontend/
│   ├── index.html
│   ├── style.css
│   ├── config.js           # API_BASE_URL — edit if backend host changes
│   └── script.js           # CRUD calls, client-side validation, search/filter
├── postman_collection.json # Import into Postman for manual API testing
└── README.md
```

## 1. Backend Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt

python manage.py migrate
python manage.py createsuperuser   # optional, for /admin/
python manage.py runserver 127.0.0.1:8000
```

The API is now live at `http://127.0.0.1:8000/api/students/`.
Django admin is at `http://127.0.0.1:8000/admin/`.

### Environment variables

Copy `.env.example` to `.env` and set a real `DJANGO_SECRET_KEY` and
`DJANGO_DEBUG=False` before any real deployment. Never commit `.env` or the
`db.sqlite3` file with real data.

## 2. Frontend Setup

No build step is required — it's plain HTML/CSS/JS.

```bash
cd frontend
python -m http.server 5500
```

Open `http://127.0.0.1:5500` in a browser. If your backend runs on a
different host/port, edit `API_BASE_URL` in `frontend/config.js`.

(CORS is already enabled on the backend so the frontend can be served from
a different origin/port than the API.)

## 3. REST API Reference

| Operation | Method | Endpoint              | Notes                              |
|-----------|--------|------------------------|-------------------------------------|
| Create    | POST   | `/api/students/`       | Returns 201 + created record, or 400 + field errors |
| Read all  | GET    | `/api/students/`       | Supports `?search=`, `?course=`, `?ordering=` |
| Read one  | GET    | `/api/students/{id}/`  | 404 if not found                    |
| Update    | PUT    | `/api/students/{id}/`  | Full update; 404 if id invalid      |
| Update    | PATCH  | `/api/students/{id}/`  | Partial update                      |
| Delete    | DELETE | `/api/students/{id}/`  | 404 if id invalid                   |

**Student fields:** `name`, `email` (unique), `age` (15–100),
`course` (choice field), `enrollment_date` (cannot be in the future).

## 4. Running Automated Tests

```bash
cd backend
python manage.py test students -v 2
```

13 tests cover: create (valid / missing fields / duplicate email / invalid
age / future date), read (empty db / populated db / single record /
search), update (valid id / invalid id), delete (valid id / invalid id).

## 5. Manual API Testing with Postman

Import `postman_collection.json` into Postman. It includes requests for
every CRUD operation plus deliberately invalid requests (missing fields,
duplicate email, bad IDs) to verify error handling, matching Section 10 of
the SOP.

## 6. Version Control

```bash
git init
git add .
git commit -m "Initial commit: Student Management System CRUD app"
```

`.gitignore` already excludes `venv/`, `__pycache__/`, `db.sqlite3`, and
`.env` so secrets and build artifacts are never committed.

## Notes on Security (Section 11 of the SOP)

- Secret key and debug flag are read from environment variables, not hard-coded.
- All input is validated server-side (serializers.py) even though the
  frontend also validates client-side.
- The ORM (Django's QuerySet API) is used throughout — no raw SQL, so
  queries are parameterized by default.
- `db.sqlite3` and `.env` are git-ignored.
